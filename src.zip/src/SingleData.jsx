import React from "react"
import Name from "./Name"


class SingleData  extends React.Component{

     selectfunc(){
         if(this.props.handler!==undefined){
            this.props.handler(this.props.data)
            console.log(this.props)
         }
     }

    render(){
        let  finalValue= null
        if(this.props.select!==undefined){
            finalValue=  <Name singleName={this.props.data.name}/>
        }

        else{
      finalValue=  <>
            <h1>{this.props.header}</h1>
             <Name singleName={this.props.selectedUser.name}/>
            <h2>{this.props.selectedUser.email}</h2>
            <h2>{this.props.selectedUser.address}</h2>
            </>

        }
        return(
            <div style={{border:this.props.border}} onClick={this.selectfunc.bind(this)}>
          {finalValue}
          </div>
        )
    }
}

export default SingleData